import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { EstilosComponent } from './estilos/estilos.component';
import { PipesComponent } from './pipes/pipes.component';
import { Formativa31Component } from './formativa31/formativa31.component';
import {  FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    EstilosComponent,
    PipesComponent,
    Formativa31Component

  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule


  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
