import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Formativa31Component } from './formativa31.component';

describe('Formativa31Component', () => {
  let component: Formativa31Component;
  let fixture: ComponentFixture<Formativa31Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Formativa31Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Formativa31Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
