import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-formativa31',
  templateUrl: './formativa31.component.html',
  styleUrls: ['./formativa31.component.css']
})
export class Formativa31Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }


  formulario:FormGroup = new FormGroup({
    cantidad: new FormControl(''),
    producto: new FormControl('')
    
  });

  productos : Producto [] = [
    new Producto("Coca Cola" , 2000),
    new Producto("Sprite" , 2000),
    new Producto("7 up" , 1800),
    new Producto("Hielo" , 1000),
    new Producto("Pisco Mistral" , 5500)
  ];
  
  precio = 0

  metodo(){

    let cantidad = this.formulario.value.cantidad ;
    let producto = this.formulario.value.producto ;
    console.log(cantidad,producto);
    let total !: number;

    for (let x of this.productos){
        if (x.nombre  == producto){
            total= x.precio * cantidad;
        } 
    }

    let totalIva = total + (total*0.19);
    let elemento : any = document.getElementById("totalPagar");
    this.precio = totalIva;


  }



}


class Producto {
  constructor(public nombre:string, public precio:number){

  }
}
