import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styleUrls: ['./pipes.component.css']
})
export class PipesComponent {

  vendedor = 'Pedro';
  sueldo = 150000;
  fecha = ['lunes' , 'miercoles' , 'viernes'];
  productos = [{
      codigo : 1,
      nombre: "Carne",
      precio: 10000
  },
  {
    codigo : 2,
    nombre: "Vino",
    precio: 15000
  },
  {
    codigo : 3,
    nombre: "Empanada",
    precio: 150
  }];

}
