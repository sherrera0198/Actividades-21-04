import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ng-if',
  templateUrl: './ng-if.component.html',
  styleUrls: ['./ng-if.component.css']
})
export class NgIfComponent  {

  personas : Persona[] =[
    new Persona('Juan', 35),
    new Persona('Pedro', 25),
    new Persona('Jose', 36),
    new Persona('Ana', 40),
    new Persona('Maria', 28),
  ]

}

class Persona {
  constructor(public nombre : string , public edad : number ){

  }
}
