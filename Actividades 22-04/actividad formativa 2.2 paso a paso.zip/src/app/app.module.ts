import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { NuevoComponent } from './nuevo/nuevo.component';
import { AngularComponent } from './angular/angular.component';
import { NgModelComponent } from './ng-model/ng-model.component';
import { FormsModule } from '@angular/forms';
import { NgForComponent } from './ng-for/ng-for.component';
import { NgIfComponent } from './ng-if/ng-if.component';
import { DatabindingComponent } from './databinding/databinding.component';
import { ProductosComponent } from './productos/productos.component';
import { ContenedorComponent } from './contenedor/contenedor.component';

@NgModule({
  declarations: [
    AppComponent,
    NuevoComponent,
    AngularComponent,
    NgModelComponent,
    NgForComponent,
    NgIfComponent,
    DatabindingComponent,
    ProductosComponent,
    ContenedorComponent,
   
  ],
  imports: [
    BrowserModule, 
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
