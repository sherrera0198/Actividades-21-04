import { StringMap } from '@angular/compiler/src/compiler_facade_interface';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productos',
  templateUrl: './productos.component.html',
  styleUrls: ['./productos.component.css']
})
export class ProductosComponent  {

  productos : Producto [] = [
    new Producto(1, "Coca Cola 3lts" , 3000),
    new Producto(2, "Leche 1 lts" , 1000),
    new Producto(3, "Galletas Triton" , 500),
    new Producto(4, "Galletas Frac" , 500),
  ]

}

class Producto {
  constructor(public codigo : number, public nombre: string, public precio : number){

  }


}
