import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';


@Component({
  selector: 'app-formulario1',
  templateUrl: './formulario1.component.html',
  styleUrls: ['./formulario1.component.css']
})
export class Formulario1Component  {

  datos !: string;
  
  
  formulario:FormGroup = new FormGroup({
    nombre: new FormControl(''),
    apellido: new FormControl(''),
    rut: new FormControl(''),
    edad: new FormControl(''),
    direccion : new FormControl('')
  });

  metodo (){
    this.datos = `Nombre : ${this.formulario.value.nombre}
                  Apellido : ${this.formulario.value.apellido}
                  Rut : ${this.formulario.value.rut}
                  Edad : ${this.formulario.value.edad}
                  direccion : ${this.formulario.value.direccion}`;
  }
}
