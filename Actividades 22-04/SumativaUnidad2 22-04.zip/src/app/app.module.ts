import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { OrdenCompraComponent } from './orden-compra/orden-compra.component';


@NgModule({
  declarations: [
    AppComponent,
    OrdenCompraComponent
  ],
  imports: [

    BrowserModule, 
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
