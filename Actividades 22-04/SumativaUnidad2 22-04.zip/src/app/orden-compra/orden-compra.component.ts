import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup , Validators} from '@angular/forms';



@Component({
  selector: 'app-orden-compra',
  templateUrl: './orden-compra.component.html',
  styleUrls: ['./orden-compra.component.css']
})
export class OrdenCompraComponent implements OnInit {


  datos !: string;
  lista !: Articulo[];
 
  formulario:FormGroup = new FormGroup({
    codigo: new FormControl('', Validators.required),
    nombre: new FormControl('', Validators.required),
    precio: new FormControl('', Validators.required),
    descripcion: new FormControl('', Validators.required)

  });

  


  constructor() { }

  ngOnInit(): void {
    this.lista =[];
    let variable = JSON.parse(localStorage.getItem("elementos") || '{}');
    if(variable!=null)
      for(let elementos of variable)
        this.lista.push(elementos)
    localStorage.clear();
  }


  agregar(){

    let error = this.validacion();
    if (error.length > 0){
      alert(`No de superó el minimo de caracteres en los sigueientes campos ${error}` )
    }else if (this.formulario.value.codigo != "" && this.formulario.value.nombre != "" && this.formulario.value.precio != "" && this.formulario.value.descripcion != ""){
        let articulo = new Articulo(this.formulario.value.codigo , this.formulario.value.nombre , this.formulario.value.precio , this.formulario.value.descripcion);
        this.lista.push(articulo);
        localStorage.setItem('elementos', JSON.stringify(this.lista));
    }

    
  }

  validacion(){

    let largoCodigo = this.formulario.value.codigo.length;
    let largoNombre = this.formulario.value.nombre.length;
    let largoPrecio = this.formulario.value.precio.length;
    let largoDescripcion = this.formulario.value.descripcion.length;


    
    let glosaError=new Array()  



    if (largoCodigo < 3 ){
        glosaError.push( "Código");
    }

    if (largoNombre < 3 ){
      glosaError.push("Nombre");
   }
    if (largoPrecio < 3){
      glosaError.push("Precio");
    }

    if (largoDescripcion < 3 ){
      glosaError.push("Descripcion");
  }

  return glosaError;
  
}

eliminar( index: number) {
  
  let codigoBorrar = 0;
  let cont = 0 ;
  for( let x of this.lista){
    if (x.codigo == index){
      codigoBorrar = cont
    } 
    cont += 1;
  }

  this.lista.splice(codigoBorrar,1); 
 
}


modificar( index: number) {
  
  let elementoModificar!:Articulo  ;
  for( let x of this.lista){
    if (x.codigo == index){
      elementoModificar = x
    } 
  }

  let idNombre = elementoModificar.codigo.toString() + elementoModificar.nombre;
  let idPrecio = elementoModificar.codigo.toString() + elementoModificar.precio;
  let idDescripcion = elementoModificar.codigo.toString() + elementoModificar.descripcion;
  let idBtn = elementoModificar.codigo.toString() + "btn";

  let elementoNombre :any = document.getElementById(idNombre);
  elementoNombre.disabled = false;

  let elementoPrecio :any = document.getElementById(idPrecio);
  elementoPrecio.disabled = false;

  let elementoDescripcion :any = document.getElementById(idDescripcion);
  elementoDescripcion.disabled = false;

  let elementoBtn :any = document.getElementById(idBtn);
  elementoBtn.disabled = false;





  

 
}


guardarModificacion(index : number){
  let elementoModificar!:Articulo  ;
  for( let x of this.lista){
    if (x.codigo == index){
      elementoModificar = x
    } 
  }
  
  let idNombre = elementoModificar.codigo.toString() + elementoModificar.nombre;
  let idPrecio = elementoModificar.codigo.toString() + elementoModificar.precio;
  let idDescripcion = elementoModificar.codigo.toString() + elementoModificar.descripcion;
  let idBtn = elementoModificar.codigo.toString() + "btn";

  let elementoNombre :any = document.getElementById(idNombre);
  elementoModificar.nombre =  elementoNombre.value;
  elementoNombre.disabled = true;

  let elementoPrecio :any = document.getElementById(idPrecio);
  elementoModificar.precio =  elementoPrecio.value;
  elementoPrecio.disabled = true;


  let elementoDescripcion :any = document.getElementById(idDescripcion);
  elementoModificar.descripcion =  elementoDescripcion.value;
  elementoDescripcion.disabled = true;

  let elementoBtn :any = document.getElementById(idBtn);
  elementoBtn.disabled = true;


}


}


class Articulo {
  constructor(public codigo: number, public nombre:string, public precio : number , public descripcion: string){

  }
}