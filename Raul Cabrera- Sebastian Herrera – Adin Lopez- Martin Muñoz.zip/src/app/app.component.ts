import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'mercado';
  titulo = ["Código" , "Nombre ", "Precio", "Descripción"]
  producto1 = ["1","Bebida", "1200", "Bebida de fantasia"];
  producto2 = ["2","Leche", "1000", "Producto Lacteo"];
  producto3 = ["3","Cafe", "1500", "Tarro de cafe"];
  producto = [this.producto1, this.producto2 , this.producto3];
}
